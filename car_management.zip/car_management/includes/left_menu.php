<div class="bg-light border-right" id="sidebar-wrapper">
    <div class="list-group list-group-flush">
        <a href="my_account.php" class="list-group-item list-group-item-action bg-light">PROFILE SETTINGS</a>
        <a href="update_password.php" class="list-group-item list-group-item-action bg-light">UPDATE PASSWORD</a>
        <a href="testimonial_post.php" class="list-group-item list-group-item-action bg-light">POST A TESTIMONIAL</a>
        <a href="my_testimonial.php" class="list-group-item list-group-item-action bg-light">MY TESTIMONIAL</a>
        <a href="my_booking.php" class="list-group-item list-group-item-action bg-light">BOOKING STATE</a>

    </div>
</div>
